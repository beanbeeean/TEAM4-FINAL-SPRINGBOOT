package com.office.libooksserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibooksServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(LibooksServerApplication.class, args);
    }

}
